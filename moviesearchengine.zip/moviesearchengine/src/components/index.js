// import React from 'react';

// function Index() {
//   render();
//   {
//     return (
//       <div className='container'>
//         <h1 className='title'>React Movie Search</h1>
//       </div>
//     );
//   }
// }

// export default Index;
